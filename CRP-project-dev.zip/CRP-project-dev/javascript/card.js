function flip(id){
  var card = document.getElementById(id);
  card.classList.toggle("flip");
}
